import { createFileRoute } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import {
  Axe,
  CloudLightning,
  Truck,
  TriangleAlert,
  ClipboardCheck,
  Phone,
  ShieldCheck,
  Clock,
  Star,
  MapPin,
  Facebook,
  Instagram,
} from "lucide-react";
import { toast } from "sonner";
import { Toaster } from "@/components/ui/sonner";
import { Reveal } from "@/components/Reveal";
import craneAsset from "@/assets/unnamed_1.jpg.asset.json";
import leaningTreeAsset from "@/assets/unnamed.jpg.asset.json";
import propertyAsset from "@/assets/thumbnail.jpg.asset.json";

const heroImg = craneAsset.url;
const ctaBg = leaningTreeAsset.url;

const PHONE = "(256) 374-2193";
const PHONE_HREF = "tel:+12563742193";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "North Alabama Tree Service | Tree Removal & Storm Response" },
      {
        name: "description",
        content:
          "Premium tree removal, storm damage response, and hazardous tree work across North Alabama. Same-day quotes, fully insured crew, zero damage guarantee.",
      },
      {
        property: "og:title",
        content: "North Alabama Tree Service | Tree Removal & Storm Response",
      },
      {
        property: "og:description",
        content:
          "Same-day quotes. Fast crews. Zero damage guarantee. Call JD and the North Alabama Tree Service crew.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const services = [
  {
    icon: Axe,
    title: "Tree Removal",
    copy: "Precision felling and rigging for trees of any size — clean, controlled, and off your property the same day.",
  },
  {
    icon: CloudLightning,
    title: "Storm & Emergency Removal",
    copy: "Tree on the roof at 9pm? We answer, we roll out, and we make your home safe again fast.",
  },
  {
    icon: TriangleAlert,
    title: "Large & Hazardous Trees",
    copy: "120-foot pines leaning over the house. Tight drop zones near power. This is the work we're built for.",
  },
  {
    icon: Truck,
    title: "Cleanup & Hauling",
    copy: "Limbs chipped, rounds loaded, ruts raked. We leave the yard looking better than we found it.",
  },
  {
    icon: ClipboardCheck,
    title: "Free Estimates",
    copy: "Straight numbers, no pressure, no surprise line items. Most quotes turned around the same day.",
  },
];

const trust = [
  { icon: Axe, stat: "20+ Trees", label: "Removed in 4 days" },
  { icon: Clock, stat: "Same Evening", label: "Emergency response" },
  { icon: ShieldCheck, stat: "100%", label: "Safety record" },
  { icon: ClipboardCheck, stat: "Fully Insured", label: "Licensed crew" },
];

const reasons = [
  {
    title: "Massive trees, zero damage",
    copy: "We take down giants standing feet from roofs, fences, and power lines — and walk away leaving the structure untouched.",
  },
  {
    title: "Pricing that beats the quotes",
    copy: "Transparent, fair, and consistently under what the big outfits charge. What we quote is what you pay.",
  },
  {
    title: "We walk the property with you",
    copy: "Before we load up, JD walks the job with you personally. Nobody leaves until you're satisfied.",
  },
  {
    title: "Storm response that shows up",
    copy: "When the weather turns, we're already moving. Often on site the same evening a tree comes down.",
  },
];

const testimonials = [
  {
    quote: "Great work from start to finish, and great prices.",
    name: "Homeowner, Madison County",
  },
  {
    quote:
      "JD and his team removed 20 huge pine trees, each over 120 feet tall, in just 4 days — safely, professionally, and at a very reasonable price compared to other quotes. I recommend them 1000%.",
    name: "Homeowner, North Alabama",
  },
  {
    quote:
      "JD came out the same evening a tree fell on our home and had his crew remove it within a day or two. Pleasant, safe, and they cleaned up perfectly.",
    name: "Storm damage client",
  },
];

const gallery = [
  { src: craneAsset.url, alt: "Crane lift removing a large oak beside a brick home" },
  { src: leaningTreeAsset.url, alt: "Storm-leaning tree resting against a two-story house" },
  { src: propertyAsset.url, alt: "North Alabama property served by the crew" },
];

function Index() {
  const [sent, setSent] = useState(false);

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    const name = String(form.get("name") ?? "").trim();
    const phone = String(form.get("phone") ?? "").trim();
    if (name.length < 2 || phone.length < 7) {
      toast.error("Please add your name and a phone number we can reach you at.");
      return;
    }
    setSent(true);
    toast.success("Request received — JD's crew will call you shortly.");
    e.currentTarget.reset();
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Toaster />

      {/* Header */}
      <header className="fixed inset-x-0 top-0 z-50 border-b border-border/60 bg-background/70 backdrop-blur-xl">
        <div className="mx-auto grid max-w-7xl grid-cols-[minmax(0,1fr)_auto] items-center gap-4 px-5 py-4 sm:px-8">
          <div className="flex min-w-0 items-center gap-3">
            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-sm bg-primary text-primary-foreground">
              <Axe className="h-5 w-5" />
            </span>
            <span className="min-w-0">
              <span className="block truncate font-display text-sm font-extrabold tracking-[0.14em] uppercase">
                North Alabama
              </span>
              <span className="block truncate text-[11px] tracking-[0.3em] text-muted-foreground uppercase">
                Tree Service
              </span>
            </span>
          </div>
          <a
            href={PHONE_HREF}
            className="inline-flex shrink-0 items-center gap-2 rounded-sm border border-primary/50 px-4 py-2 text-sm font-semibold text-primary transition-colors hover:bg-primary hover:text-primary-foreground"
          >
            <Phone className="h-4 w-4" />
            <span className="hidden sm:inline">{PHONE}</span>
            <span className="sm:hidden">Call</span>
          </a>
        </div>
      </header>

      {/* Hero */}
      <section className="relative flex min-h-screen items-end overflow-hidden">
        <img
          src={heroImg}
          alt="Crane lift removing a towering tree beside a North Alabama home"
          width={1920}
          height={1280}
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div
          className="absolute inset-0"
          style={{ background: "var(--gradient-hero)" }}
        />
        <div className="relative mx-auto w-full max-w-7xl px-5 pt-32 pb-20 sm:px-8 sm:pb-28">
          <Reveal>
            <p className="eyebrow">Huntsville · Decatur · Athens · Madison</p>
            <h1 className="mt-6 max-w-4xl text-5xl leading-[0.95] sm:text-7xl lg:text-8xl">
              North Alabama's Most Trusted Name in{" "}
              <span className="text-primary">Tree Removal</span>
            </h1>
          </Reveal>
          <Reveal delay={140}>
            <p className="mt-7 max-w-xl text-lg leading-relaxed text-muted-foreground">
              Fast crews, obsessive safety, and a finished yard you'd never know
              we worked in. The crew you call once and never worry about again.
            </p>
          </Reveal>
          <Reveal delay={260}>
            <div className="mt-10 flex flex-col gap-3 sm:flex-row sm:items-center">
              <a
                href="#quote"
                className="inline-flex items-center justify-center rounded-sm px-8 py-4 text-sm font-bold tracking-[0.12em] text-primary-foreground uppercase transition-transform hover:scale-[1.02]"
                style={{
                  background: "var(--gradient-gold)",
                  boxShadow: "var(--shadow-gold)",
                }}
              >
                Get Your Free Quote Now
              </a>
              <a
                href={PHONE_HREF}
                className="inline-flex items-center justify-center gap-2 rounded-sm border border-foreground/25 px-8 py-4 text-sm font-bold tracking-[0.12em] uppercase backdrop-blur-sm transition-colors hover:border-primary hover:text-primary"
              >
                <Phone className="h-4 w-4" /> Call JD Directly
              </a>
            </div>
            <p className="mt-6 text-xs tracking-[0.22em] text-muted-foreground uppercase">
              Same-day quotes · Fast crews · Zero damage guarantee
            </p>
          </Reveal>
        </div>
      </section>

      {/* Trust bar */}
      <section className="border-y border-border bg-card">
        <div className="mx-auto grid max-w-7xl grid-cols-2 gap-px bg-border lg:grid-cols-4">
          {trust.map((t) => (
            <div
              key={t.stat}
              className="flex flex-col gap-3 bg-card px-6 py-10 sm:px-8"
            >
              <t.icon className="h-5 w-5 text-primary" />
              <p className="font-display text-2xl leading-none sm:text-3xl">
                {t.stat}
              </p>
              <p className="text-xs tracking-[0.18em] text-muted-foreground uppercase">
                {t.label}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Services */}
      <section id="services" className="mx-auto max-w-7xl px-5 py-28 sm:px-8 sm:py-36">
        <Reveal>
          <p className="eyebrow">What we do</p>
          <h2 className="mt-5 max-w-2xl text-4xl sm:text-6xl">
            Heavy work, handled clean.
          </h2>
        </Reveal>
        <div className="mt-16 grid gap-px bg-border sm:grid-cols-2 lg:grid-cols-3">
          {services.map((s, i) => (
            <Reveal key={s.title} delay={i * 80}>
              <article className="group h-full bg-background p-8 transition-colors hover:bg-card sm:p-10">
                <s.icon className="h-7 w-7 text-primary transition-transform duration-500 group-hover:-translate-y-1" />
                <h3 className="mt-8 text-2xl">{s.title}</h3>
                <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
                  {s.copy}
                </p>
              </article>
            </Reveal>
          ))}
          <div className="hidden bg-card lg:block" />
        </div>
      </section>

      {/* Why choose us */}
      <section className="border-y border-border bg-card/60">
        <div className="mx-auto grid max-w-7xl gap-16 px-5 py-28 sm:px-8 sm:py-36 lg:grid-cols-[0.9fr_1.1fr]">
          <Reveal>
            <p className="eyebrow">Why homeowners call us back</p>
            <h2 className="mt-5 text-4xl sm:text-6xl">
              We treat your yard like it's ours.
            </h2>
            <p className="mt-6 max-w-md text-muted-foreground">
              Safety-obsessed. Fast-responding. No-nonsense. Every job ends the
              same way — with you walking the property and telling us it's right.
            </p>
          </Reveal>
          <div className="grid gap-px bg-border sm:grid-cols-2">
            {reasons.map((r, i) => (
              <Reveal key={r.title} delay={i * 90}>
                <div className="h-full bg-card p-8">
                  <span className="font-display text-sm text-primary">
                    0{i + 1}
                  </span>
                  <h3 className="mt-5 text-xl">{r.title}</h3>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                    {r.copy}
                  </p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="mx-auto max-w-7xl px-5 py-28 sm:px-8 sm:py-36">
        <Reveal>
          <p className="eyebrow">Word of mouth</p>
          <h2 className="mt-5 text-4xl sm:text-6xl">Straight from the yard.</h2>
        </Reveal>
        <div className="mt-16 grid gap-8 lg:grid-cols-3">
          {testimonials.map((t, i) => (
            <Reveal key={t.name} delay={i * 110} className="h-full">
              <figure
                className="flex h-full flex-col justify-between border border-border bg-card p-8 sm:p-10"
                style={{ boxShadow: "var(--shadow-lux)" }}
              >
                <div>
                  <div className="flex gap-1">
                    {Array.from({ length: 5 }).map((_, s) => (
                      <Star
                        key={s}
                        className="h-4 w-4 fill-primary text-primary"
                      />
                    ))}
                  </div>
                  <blockquote className="mt-7 font-display text-lg leading-snug sm:text-xl">
                    "{t.quote}"
                  </blockquote>
                </div>
                <figcaption className="mt-8 text-xs tracking-[0.2em] text-muted-foreground uppercase">
                  {t.name}
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </section>

      {/* Emergency banner */}
      <section className="relative overflow-hidden border-y border-primary/30">
        <div
          className="absolute inset-0"
          style={{ background: "var(--gradient-gold)" }}
        />
        <div className="relative mx-auto flex max-w-7xl flex-col items-start gap-8 px-5 py-20 sm:px-8 lg:flex-row lg:items-center lg:justify-between">
          <div className="max-w-2xl text-primary-foreground">
            <p className="text-xs font-bold tracking-[0.3em] uppercase opacity-70">
              Emergency service
            </p>
            <h2 className="mt-4 text-4xl leading-tight sm:text-5xl">
              Tree down? We respond fast — even same-day.
            </h2>
          </div>
          <a
            href={PHONE_HREF}
            className="inline-flex shrink-0 items-center gap-3 rounded-sm bg-charcoal px-8 py-5 text-sm font-bold tracking-[0.12em] text-primary uppercase transition-transform hover:scale-[1.03]"
          >
            <Phone className="h-4 w-4" /> Call {PHONE}
          </a>
        </div>
      </section>

      {/* Gallery */}
      <section className="mx-auto max-w-7xl px-5 py-28 sm:px-8 sm:py-36">
        <Reveal>
          <p className="eyebrow">On the job</p>
          <h2 className="mt-5 text-4xl sm:text-6xl">Recent work.</h2>
        </Reveal>
        <div className="mt-16 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {gallery.map((g, i) => (
            <Reveal key={g.alt} delay={i * 80}>
              <div className="group relative aspect-4/5 overflow-hidden border border-border">
                <img
                  src={g.src}
                  alt={g.alt}
                  loading="lazy"
                  width={1024}
                  height={1024}
                  className="h-full w-full object-cover transition-transform duration-[1200ms] ease-out group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-charcoal/30 opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* Final CTA + form */}
      <section id="quote" className="relative overflow-hidden">
        <img
          src={ctaBg}
          alt=""
          aria-hidden="true"
          loading="lazy"
          width={1920}
          height={1080}
          className="absolute inset-0 h-full w-full object-cover opacity-70"
        />
        <div
          className="absolute inset-0"
          style={{ background: "var(--gradient-hero)" }}
        />
        <div className="relative mx-auto grid max-w-7xl gap-16 px-5 py-28 sm:px-8 sm:py-36 lg:grid-cols-2">
          <Reveal>
            <p className="eyebrow">Free estimate</p>
            <h2 className="mt-5 text-4xl leading-[1.02] sm:text-6xl">
              Get a free quote — trusted by North Alabama homeowners.
            </h2>
            <p className="mt-6 max-w-md text-muted-foreground">
              Tell us what you're looking at. Most quotes go out the same day,
              and emergencies get a call back immediately.
            </p>
            <a
              href={PHONE_HREF}
              className="mt-10 inline-flex items-center gap-3 border-b border-primary pb-2 font-display text-2xl text-primary sm:text-3xl"
            >
              <Phone className="h-5 w-5" /> {PHONE}
            </a>
          </Reveal>

          <Reveal delay={140}>
            <form
              onSubmit={handleSubmit}
              className="border border-border bg-card/90 p-8 backdrop-blur-md sm:p-10"
              style={{ boxShadow: "var(--shadow-lux)" }}
            >
              <div className="grid gap-5">
                <Field label="Name" name="name" placeholder="Your name" required />
                <Field
                  label="Phone"
                  name="phone"
                  type="tel"
                  placeholder="(256) 000-0000"
                  required
                />
                <Field
                  label="Address"
                  name="address"
                  placeholder="Street, city"
                />
                <label className="block">
                  <span className="text-xs tracking-[0.2em] text-muted-foreground uppercase">
                    Message
                  </span>
                  <textarea
                    name="message"
                    rows={4}
                    maxLength={1000}
                    placeholder="How many trees, how close to the house, anything urgent…"
                    className="mt-2 w-full resize-none rounded-sm border border-input bg-background px-4 py-3 text-sm outline-none placeholder:text-muted-foreground/70 focus:border-primary"
                  />
                </label>
                <button
                  type="submit"
                  className="mt-2 w-full rounded-sm px-8 py-4 text-sm font-bold tracking-[0.14em] text-primary-foreground uppercase transition-transform hover:scale-[1.01]"
                  style={{ background: "var(--gradient-gold)" }}
                >
                  {sent ? "Request Sent" : "Request My Free Quote"}
                </button>
                <p className="text-center text-xs text-muted-foreground">
                  Or call JD directly — we answer after hours.
                </p>
              </div>
            </form>
          </Reveal>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-charcoal">
        <div className="mx-auto grid max-w-7xl gap-12 px-5 py-16 sm:px-8 lg:grid-cols-4">
          <div>
            <div className="flex items-center gap-3">
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-sm bg-primary text-primary-foreground">
                <Axe className="h-5 w-5" />
              </span>
              <span>
                <span className="block font-display text-sm tracking-[0.14em] uppercase">
                  North Alabama
                </span>
                <span className="block text-[11px] tracking-[0.3em] text-muted-foreground uppercase">
                  Tree Service
                </span>
              </span>
            </div>
            <p className="mt-6 text-sm text-muted-foreground">
              The crew you call once and never worry about again.
            </p>
          </div>

          <div>
            <h3 className="text-xs tracking-[0.24em] text-primary uppercase">
              Service area
            </h3>
            <p className="mt-4 flex items-start gap-2 text-sm text-muted-foreground">
              <MapPin className="mt-0.5 h-4 w-4 shrink-0" />
              All of North Alabama — Huntsville, Madison, Athens, Decatur,
              Cullman, Scottsboro
            </p>
          </div>

          <div>
            <h3 className="text-xs tracking-[0.24em] text-primary uppercase">
              Hours
            </h3>
            <p className="mt-4 text-sm text-muted-foreground">
              Mon–Sat: 7am – 7pm
              <br />
              Emergency storm response: 24/7
            </p>
            <a
              href={PHONE_HREF}
              className="mt-4 inline-block text-sm font-semibold text-primary"
            >
              {PHONE}
            </a>
          </div>

          <div>
            <h3 className="text-xs tracking-[0.24em] text-primary uppercase">
              Licensed & insured
            </h3>
            <p className="mt-4 inline-flex items-center gap-2 border border-primary/40 px-3 py-2 text-xs tracking-[0.16em] text-primary uppercase">
              <ShieldCheck className="h-4 w-4" /> Fully insured crew
            </p>
            <div className="mt-6 flex gap-3">
              <a
                href="#"
                aria-label="Facebook"
                className="grid h-9 w-9 place-items-center border border-border text-muted-foreground transition-colors hover:border-primary hover:text-primary"
              >
                <Facebook className="h-4 w-4" />
              </a>
              <a
                href="#"
                aria-label="Instagram"
                className="grid h-9 w-9 place-items-center border border-border text-muted-foreground transition-colors hover:border-primary hover:text-primary"
              >
                <Instagram className="h-4 w-4" />
              </a>
            </div>
          </div>
        </div>
        <div className="border-t border-border">
          <p className="mx-auto max-w-7xl px-5 py-6 text-xs text-muted-foreground sm:px-8">
            © {new Date().getFullYear()} North Alabama Tree Service. All rights
            reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}

function Field({
  label,
  name,
  type = "text",
  placeholder,
  required,
}: {
  label: string;
  name: string;
  type?: string;
  placeholder?: string;
  required?: boolean;
}) {
  return (
    <label className="block">
      <span className="text-xs tracking-[0.2em] text-muted-foreground uppercase">
        {label}
      </span>
      <input
        name={name}
        type={type}
        required={required}
        maxLength={120}
        placeholder={placeholder}
        className="mt-2 w-full rounded-sm border border-input bg-background px-4 py-3 text-sm outline-none placeholder:text-muted-foreground/70 focus:border-primary"
      />
    </label>
  );
}
